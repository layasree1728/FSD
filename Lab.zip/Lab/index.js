const express = require('express')
const mongoose = require('mongoose')
const app = express()
const url = 'mongodb://localhost/stuDB'
mongoose.connect(url,{useNewUrlParser:true})

const con = mongoose.connection



con.on('open', ()=> {

    console.log("connected buddy")
})

app.use(express.json())
const stuRouter = require('./routes/collections')
app.use('/stud', stuRouter)

app.listen(9000, () => {
    console.log("server start")
})